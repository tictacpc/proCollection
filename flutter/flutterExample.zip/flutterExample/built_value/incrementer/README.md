# Built Value Incrementer

The incrementer app modified to use built values

## Getting Started

In order to run this, the built values needed to be built. Run:

```
flutter packages get
```

followed by

```
flutter pub pub run build_runner build
```

to generate the code. Then run as a normal Flutter app.