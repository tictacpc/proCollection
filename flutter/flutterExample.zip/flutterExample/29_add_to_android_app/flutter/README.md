# add_flutter_to_android

A new flutter module project.

## Getting Started

For help getting started with Flutter, view our online
[documentation](https://flutter.io/).
