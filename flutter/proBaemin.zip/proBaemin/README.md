
# Baemin App Clone

Flutter UI challenge

<a href="https://github.com/Solido/awesome-flutter">
   <img alt="Awesome Flutter" src="https://img.shields.io/badge/Awesome-Flutter-blue.svg?longCache=true&style=flat-square" />
</a>

## Why ?

I have a habit of ordering food every afternoon, in the order applications I have used, I really love  UI/UX of BEAMIN app. So I chose BEAMIN as a UI Challenge.

## Target ScreenShot

<img height="480px" src="res/1.jpg"> <img height="480px" src="res/3.jpg">  <img height="480px" src="res/2.jpg">


## Demo
<img height="480px" src="res/demo.gif">


## Todo
- Bloc 
- Provider
- Shop Details.
