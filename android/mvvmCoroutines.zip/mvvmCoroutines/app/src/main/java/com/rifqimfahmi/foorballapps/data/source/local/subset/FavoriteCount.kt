package com.rifqimfahmi.foorballapps.data.source.local.subset

/*
 * Created by Rifqi Mulya Fahmi on 08/12/18.
 */
 
data class FavoriteCount(
    val favCount: Int
)