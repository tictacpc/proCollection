package com.rifqimfahmi.foorballapps.vo

/*
 * Created by Rifqi Mulya Fahmi on 21/11/18.
 */

enum class Status {
    SUCCESS,
    ERROR,
    LOADING,
    EMPTY
}