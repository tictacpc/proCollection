package dev.marcosfarias.pokedex.di

val appComponent = listOf(
    databaseModule,
    networkModule,
    viewModelsModule
)
