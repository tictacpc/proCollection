package dev.marcosfarias.pokedex.model

class Generation(
    val id: Int,
    val title: String,
    val image: Int
)
