package dev.marcosfarias.pokedex.model

class News
