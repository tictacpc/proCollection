package com.android.post.presentation.posts

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import com.android.post.R
import com.android.post.databinding.ActivityPostsBinding
import com.android.post.utils.isNetworkAvailable
import kotlinx.android.synthetic.main.activity_posts.*
import kotlinx.coroutines.ExperimentalCoroutinesApi
import org.koin.android.viewmodel.ext.android.viewModel


class PostsActivity : AppCompatActivity() {

    private lateinit var activityPostsBinding: ActivityPostsBinding
    private var mAdapter: PostsAdapter? = null
    private val postViewModel: PostsViewModel by viewModel()


    @ExperimentalCoroutinesApi
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        activityPostsBinding = DataBindingUtil.setContentView(this, R.layout.activity_posts)
        mAdapter = PostsAdapter()
        activityPostsBinding.postsRecyclerView.adapter = mAdapter

        if (isNetworkAvailable()) {
            postViewModel.getPosts()
        } else Toast.makeText(
            this,
            getString(R.string.no_internet_connection),
            Toast.LENGTH_SHORT
        ).show()

        postViewModel.postsData.observe(this, Observer {
            activityPostsBinding.postsProgressBar.visibility = View.GONE
            mAdapter?.mPostList = it
        })

        postViewModel.messageData.observe(this, Observer {
            Toast.makeText(this, it, Toast.LENGTH_LONG).show()
        })

        postViewModel.showProgressbar.observe(this, Observer { isVisible ->
            posts_progress_bar.visibility = if (isVisible) View.VISIBLE else View.GONE
        })
    }

    companion object {
        private val TAG = PostsActivity::class.java.name
    }
}
